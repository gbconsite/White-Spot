<?php
/**
 * Beispiel MRT-API: Adressen hinzufügen/updaten
 *
 * Voraussezung: PHP mit php-curl, ggf. nachzuinstallieren
 *
 * Dokumentation:  https://www.zustellplaner.biz/MultiRoute_Tour!_API.html#Adressen-HinzufügenUpdaten
 *
 */

include 'settings.php';
$url .= 'fernsteuerung/add_and_update_adresse';

$data = array(
  'update'    => true,
  'insert'    => true,
  'adresse'  => array()
);

array_push($data['adresse'], array(
  'oi' => 'GBC93385',
  'plz' => '10119',
  'ort' => 'Berlin',
  'ort_zusatz' => null,
  'strasse' => 'Schwedter Straße',
  'hausnummer' => '22',
  'hausnummer_zusatz' => '',
  'is_active' => true,
  'notice' => null,
  'privathaushalte' => 0,
  'gewerbebetriebe' => 0,
  'werbeverweigerer' => 0,
  'latitude' => 52.5347133208835,
  'longitude' => 13.4075689315796
));

array_push($data['adresse'], array(
  'oi' => 'GBC360693',
  'plz' => '84030',
  'ort' => 'Ergolding',
  'ort_zusatz' => null,
  'strasse' => 'Schinderstraßl',
  'hausnummer' => '5',
  'hausnummer_zusatz' => 'D',
  'is_active' => true,
  'notice' => null,
  'privathaushalte' => 0,
  'gewerbebetriebe' => 0,
  'werbeverweigerer' => null,
  'longitude' => 12.1660333871841,
  'latitude' => 48.5649005287186
));

array_push($data['adresse'], array(
  'oi' => '14272346',
  'plz' => '34626',
  'ort' => 'Neukirchen',
  'ortsteil' => 'Knüllgebirge',
  'ort_zusatz' => 'Asterode',
  'strasse' => 'Am Gänseborn',
  'hausnummer' => '12',
  'is_active' => true,
  'notice' => null,
  'privathaushalte' => 0,
  'gewerbebetriebe' => 0,
  'werbeverweigerer' => null
));

$post_data = json_encode($data);
$crl = curl_init($url);

curl_setopt($crl, CURLOPT_USERPWD, $username . ":" . $password);  
curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($crl, CURLINFO_HEADER_OUT, true);
curl_setopt($crl, CURLOPT_POST, true);
curl_setopt($crl, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($crl, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Content-Length: ' . strlen($post_data)));
$result = curl_exec($crl);
  
if ($result === false) {
  print_r('Curl error: ' . curl_error($crl));
  die();
} else {
  $rueckgabe = json_decode($result);
}

curl_close($crl);

if (is_null($rueckgabe)) {
  echo 'Keine Ergebnisse für die Abfrage' . PHP_EOL;
  die();
}

// ab hier kann mit den Ergebnissen weitergearbeitet werden
print_r($rueckgabe);
