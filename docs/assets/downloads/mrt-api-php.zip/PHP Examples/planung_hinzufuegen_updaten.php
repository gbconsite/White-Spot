<?php
/**
 * Beispiel MRT-API: Planung hinzufügen / updaten
 *
 * Voraussezung: PHP mit php-curl, ggf. nachzuinstallieren
 *
 * Dokumentation:  https://www.zustellplaner.biz/MultiRoute_Tour!_API.html#Planung-HinzufügenUpdaten
 *
 */

include 'settings.php';
$url .= 'fernsteuerung/planung/add_and_update';

$data = array(
  'update'  => true,
  'insert'  => true,
  'planung' => array()
);


array_push($data['planung'], array(
  'nr' => 'Planung 1',
  'name' => 'Meine Planung',
  'depot' => 'CS3'
));
array_push($data['planung'], array(
  'nr' => 'Planung 2',
  'name' => '',
  'depot' => null
));
array_push($data['planung'], array(
  'nr' => 'Planung 3',
  'name' => '',
  'depot' => null
));


$post_data = json_encode($data);
$crl = curl_init($url);

curl_setopt($crl, CURLOPT_USERPWD, $username . ":" . $password);  
curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($crl, CURLINFO_HEADER_OUT, true);
curl_setopt($crl, CURLOPT_POST, true);
curl_setopt($crl, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($crl, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Content-Length: ' . strlen($post_data)));
$result = curl_exec($crl);
  
if ($result === false) {
  print_r('Curl error: ' . curl_error($crl));
  die();
} else {
  $rueckgabe = json_decode($result);
}

curl_close($crl);

if (is_null($rueckgabe)) {
  echo 'Keine Ergebnisse für die Abfrage' . PHP_EOL;
  die();
}

// ab hier kann mit den Ergebnissen weitergearbeitet werden
print_r($rueckgabe);
