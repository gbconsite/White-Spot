<?php
/**
 * Beispiel MRT-API: Planungsdefinition löschen
 *
 * Voraussezung: PHP mit php-curl, ggf. nachzuinstallieren
 *
 * Dokumentation:  https://www.zustellplaner.biz/MultiRoute_Tour!_API.html#Planungsdefinition-hinzufügen-bzw-löschen
 *
 */

include 'settings.php';
$url .= 'fernsteuerung/planung/delete_definition';

$data = array(
  'planung' => 'Planung 1',
  'oi' => array()
);

array_push($data['oi'], 'GBC93385');
array_push($data['oi'], 'GBC360693');
array_push($data['oi'], '14272346');

$post_data = json_encode($data);
$crl = curl_init($url);

curl_setopt($crl, CURLOPT_USERPWD, $username . ":" . $password);  
curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($crl, CURLINFO_HEADER_OUT, true);
curl_setopt($crl, CURLOPT_POST, true);
curl_setopt($crl, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($crl, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Content-Length: ' . strlen($post_data)));
$result = curl_exec($crl);
  
if ($result === false) {
  print_r('Curl error: ' . curl_error($crl));
  die();
} else {
  $rueckgabe = json_decode($result);
}

curl_close($crl);

if (is_null($rueckgabe)) {
  echo 'Keine Ergebnisse für die Abfrage' . PHP_EOL;
  die();
}

// ab hier kann mit den Ergebnissen weitergearbeitet werden
print_r($rueckgabe);
