<?php

$username = ''; // Der Benutzer, der die API benutzt
$password = ''; // das zugehörige Passwort
$url      = ''; // Die API-Basis-Url, bei Saas z.B: https://tour.multiroute.de/
