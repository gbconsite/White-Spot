<?php
/**
 * Beispiel MRT-API: Flotte löschen
 *
 * Voraussezung: PHP mit php-curl, ggf. nachzuinstallieren
 *
 * Dokumentation:  https://www.zustellplaner.biz/MultiRoute_Tour!_API.html#Flotten
 *
 */

include 'settings.php';

$flotten_id = 11;
$url .= 'fernsteuerung/flotte/' . $flotten_id;

$crl = curl_init($url);

curl_setopt($crl, CURLOPT_USERPWD, $username . ":" . $password);  
curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($crl, CURLINFO_HEADER_OUT, true);
curl_setopt($crl, CURLOPT_CUSTOMREQUEST, 'DELETE');
curl_setopt($crl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($crl);
  
if ($result === false) {
  print_r('Curl error: ' . curl_error($crl));
  die();
} else {
  $rueckgabe = json_decode($result);
}

curl_close($crl);

if (is_null($rueckgabe)) {
  echo 'Keine Ergebnisse für die Abfrage' . PHP_EOL;
  die();
}

// ab hier kann mit den Ergebnissen weitergearbeitet werden
print_r($rueckgabe);
