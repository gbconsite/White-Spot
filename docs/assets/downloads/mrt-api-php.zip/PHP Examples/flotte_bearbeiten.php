<?php
/**
 * Beispiel MRT-API: Flotte bearbeiten
 *
 * Voraussezung: PHP mit php-curl, ggf. nachzuinstallieren
 *
 * Dokumentation:  https://www.zustellplaner.biz/MultiRoute_Tour!_API.html#Flotten
 *
 */

include 'settings.php';

$flotten_id = 11;
$url .= 'fernsteuerung/flotte/' . $flotten_id;

$data = array(
  'fleet' => array(
    'name' => 'Standardflotte',
    'vehicles' => array()
  )
);

$vehicle_1 = array(
  'name' => 'Fahrzeug 1',
  'number' => 1,
  'amount' => 1,
  'start' => array('type' => 'depot'),
  'end' => array('type' => 'depot'),
  'capacity' => 5000,
  'driving' => '[09:00,13:00]',
  'break' => array('timewindows' => '[11:00,12:00]', 'duration' => 30),
  'skills' => array('rot')
);

$vehicle_2 = array(
  'name' => 'Fahrzeug 2',
  'number' => 1,
  'amount' => 1,
  'start' => array('type' => 'depot'),
  'end' => array('type' => 'depot'),
  'capacity' => 2500,
  'driving' => '[09:00,13:00]',
  'break' => array('timewindows' => '[11:00,12:00]', 'duration' => 30),
  'skills' => array('rot')
);

array_push($data['fleet']['vehicles'], $vehicle_1);
array_push($data['fleet']['vehicles'], $vehicle_2);

$post_data = json_encode($data);
$crl = curl_init($url);

curl_setopt($crl, CURLOPT_USERPWD, $username . ":" . $password);  
curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($crl, CURLINFO_HEADER_OUT, true);
curl_setopt($crl, CURLOPT_CUSTOMREQUEST, 'PUT');
// curl_setopt($crl, CURLOPT_PUT, true);
curl_setopt($crl, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($crl, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Content-Length: ' . strlen($post_data)));
$result = curl_exec($crl);
  
if ($result === false) {
  print_r('Curl error: ' . curl_error($crl));
  die();
} else {
  $rueckgabe = json_decode($result);
}

curl_close($crl);

if (is_null($rueckgabe)) {
  echo 'Keine Ergebnisse für die Abfrage' . PHP_EOL;
  die();
}

// ab hier kann mit den Ergebnissen weitergearbeitet werden
print_r($rueckgabe);
